import React, { useState } from 'react';
import { useLocation } from 'react-router-dom';
import './Chat.css';

const Chat = () => {
  const location = useLocation();
  const { name } = location.state || { name: 'Anonymous' };
  const [messages, setMessages] = useState([]);
  const [message, setMessage] = useState('');

  const handleSend = () => {
    if (message.trim()) {
      setMessages([...messages, { user: name, text: message }]);
      setMessage('');
    }
  };

  return (
    <div className="chat-container">
      <h1>Chat</h1>
      <div className="messages-container">
        {messages.map((msg, index) => (
          <div
            key={index}
            className={`message ${msg.user === name ? 'sent' : 'received'}`}
          >
            <strong>{msg.user}:</strong> {msg.text}
          </div>
        ))}
      </div>
      <input
        type="text"
        value={message}
        onChange={(e) => setMessage(e.target.value)}
        placeholder="Escreva sua mensagem"
      />
      <button onClick={handleSend}>Enviar</button>
    </div>
  );
};

export default Chat;
