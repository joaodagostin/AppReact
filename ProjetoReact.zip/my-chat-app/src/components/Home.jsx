import React, { useState } from 'react';
import { useNavigate } from 'react-router-dom';

const Home = () => {
  const [name, setName] = useState('');
  const navigate = useNavigate();

  const handleSubmit = () => {
    if (name) {
      navigate('/chat', { state: { name } });
    }
  };

  return (
    <div>
      <h1>Chat de Atendimento</h1>
      <input 
        type="text" 
        value={name} 
        onChange={(e) => setName(e.target.value)} 
        placeholder="Informe seu nome" 
      />
      <button onClick={handleSubmit}>Entrar no Chat</button>
    </div>
  );
};

export default Home;
